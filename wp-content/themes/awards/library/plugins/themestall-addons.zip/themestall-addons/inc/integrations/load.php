<?php

/**
 * Class for managing integrations with other plugins
 */
class Ts_Integrations {

}